<section class="section" style="padding-top: 150px;">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <p class="section-subtitle">Contact</p>
            <h2 class="section-title">Get In Touch</h2>
            <p>Have a project in mind? Let's talk about it.</p>
        </div>
        
        <div class="row g-5">
            <div class="col-lg-5">
                <div class="contact-info animate-on-scroll">
                    <h3 class="mb-4">Let's Connect</h3>
                    <p style="color: #888; margin-bottom: 2rem;">I'm always open to discussing new projects, creative ideas, or opportunities to be part of your visions.</p>
                    
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div>
                            <h5>Location</h5>
                            <p>Janakpur, Nepal</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div>
                            <h5>Phone</h5>
                            <p>+977 9825827901</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div>
                            <h5>Email</h5>
                            <p>roh78382@gmail.com</p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-globe"></i>
                        </div>
                        <div>
                            <h5>Freelance</h5>
                            <p>Available</p>
                        </div>
                    </div>
                    
                    <div class="social-links mt-4">
                        <a href="https://twitter.com/RohanManda18183" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.facebook.com/profile.php?id=100053022250339" target="_blank"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.linkedin.com/in/rohan-mandal-a43358304/" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                        <a href="https://www.instagram.com/rohan.mandal07/" target="_blank"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-7">
                <div class="contact-form-wrapper animate-on-scroll">
                    <form class="contact-form" id="contactForm">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <input type="text" class="form-control-custom w-100" placeholder="Your Name" required>
                            </div>
                            <div class="col-md-6">
                                <input type="email" class="form-control-custom w-100" placeholder="Your Email" required>
                            </div>
                            <div class="col-12">
                                <input type="text" class="form-control-custom w-100" placeholder="Subject" required>
                            </div>
                            <div class="col-12">
                                <textarea class="form-control-custom w-100" rows="6" placeholder="Your Message" required></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary-custom w-100">
                                    <i class="fas fa-paper-plane me-2"></i>Send Message
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background: rgba(255,255,255,0.02);">
    <div class="container">
        <div class="section-header animate-on-scroll">
            <p class="section-subtitle">Map</p>
            <h2 class="section-title">Find Me</h2>
        </div>
        
        <div class="map-container animate-on-scroll">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d10539.496515592871!2d85.35131387571364!3d27.673072486650277!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2snp!4v1776582303859!5m2!1sen!2snp" 
                width="100%" 
                height="450" 
                style="border:0; border-radius: 20px;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>
</section>

<style>
.contact-info {
    padding: 2rem;
}

.contact-item {
    display: flex;
    align-items: flex-start;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.contact-icon {
    width: 50px;
    height: 50px;
    background: var(--gradient);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    color: #fff;
    flex-shrink: 0;
}

.contact-item h5 {
    margin-bottom: 0.25rem;
    font-size: 1rem;
}

.contact-item p {
    color: #888;
    margin-bottom: 0;
}

.contact-form-wrapper {
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.05);
    border-radius: 20px;
    padding: 2rem;
}

.map-container {
    border-radius: 20px;
    overflow: hidden;
}

@media (max-width: 991px) {
    .contact-info {
        margin-bottom: 2rem;
    }
}
</style>